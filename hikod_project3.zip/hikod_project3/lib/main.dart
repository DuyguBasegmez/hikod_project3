import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'AddTaskScreen.dart';

void main() {
  runApp(const MyApp());
}

class Item {
  final String name;
  final String startDate;
  final String description;
  final String endDate;

  Item(this.name, this.description, this.startDate, this.endDate);
}

class ItemList with ChangeNotifier {
  List<Item> _items = [
    Item('Task 1', 'MATH255 Homework', '8 October', '13 October'),
    Item('Task 2', 'CENG211 Homework', '11 October', '28 October'),
    Item('Task 3', 'CENG213 Homework', '18 October', '29 October'),
    Item('Task 4', 'Coding Practice', '9 October', '10 October'),
  ];

  List<Item> get items => [..._items];

  void addItem(Item item) {
    _items.add(item);
    notifyListeners();
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ItemList(),
      child: MaterialApp(
        home: ItemListScreen(),
      ),
    );
  }
}

class ItemListScreen extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    final itemList = Provider.of<ItemList>(context);
    final items = itemList.items;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple.shade200, // AppBar'ın arka plan rengini mor yapın
        title: Text('TO DO LIST',style: TextStyle(color: Colors.black),),
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (ctx, index) {
                  return Card(
                    color: Colors.deepPurple.shade50,
                    elevation: 3,
                    margin: EdgeInsets.all(7),
                    child: ListTile(
                      title: Text(items[index].name),
                      subtitle: Text(
                        'Description: ${items[index].description}\nStart Date: ${items[index].startDate}\nEnd Date: ${items[index].endDate}',
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddTaskScreen()),
              );
            },
            child: Text('Add Task', style: TextStyle(color: Colors.black)),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepPurple.shade100,
            ),
          ),
        ],
      ),
    );
  }
}
